<?php
/**
 * ═══════════════════════════════════════════════════════════════
 * MODIFICACIONES PARA bot_imei_corregido.php
 * ═══════════════════════════════════════════════════════════════
 * 
 * INSTRUCCIONES:
 * Copia estos bloques en tu archivo bot_imei_corregido.php
 * en las ubicaciones indicadas
 * 
 */

// ═══════════════════════════════════════════════════════════════
// MODIFICACIÓN 1: AGREGAR REQUIRES (Línea 26)
// ═══════════════════════════════════════════════════════════════
// REEMPLAZAR:
// require_once(__DIR__ . '/config_bot.php');
// require_once(__DIR__ . '/config_imeidb.php');
// require_once(__DIR__ . '/imeidb_api.php');
//
// CON:

require_once(__DIR__ . '/config_bot.php');
require_once(__DIR__ . '/config_imeidb.php');
require_once(__DIR__ . '/config_pagos.php');        // ← NUEVO
require_once(__DIR__ . '/imeidb_api.php');
require_once(__DIR__ . '/sistema_pagos.php');       // ← NUEVO
require_once(__DIR__ . '/generador_qr.php');        // ← NUEVO

// ═══════════════════════════════════════════════════════════════
// MODIFICACIÓN 2: REEMPLAZAR getTecladoPrincipal (Línea ~600)
// ═══════════════════════════════════════════════════════════════

function getTecladoPrincipal($esAdmin = false) {
    $botones = [
        [
            ['text' => '📱 Generar IMEI'],
            ['text' => '💳 Mis Créditos']
        ],
        [
            ['text' => '💰 Comprar Créditos'],   // ← NUEVO
            ['text' => '📋 Mis Órdenes']         // ← NUEVO
        ],
        [
            ['text' => '📊 Mi Perfil'],
            ['text' => '📜 Historial']
        ],
        [
            ['text' => '❓ Ayuda']
        ]
    ];
    
    if ($esAdmin) {
        $botones[] = [['text' => '👑 Panel Admin']];
    }
    
    $teclado = [
        'keyboard' => $botones,
        'resize_keyboard' => true,
        'one_time_keyboard' => false
    ];
    
    return json_encode($teclado);
}

// ═══════════════════════════════════════════════════════════════
// MODIFICACIÓN 3: REEMPLAZAR getTecladoAdmin (Línea ~630)
// ═══════════════════════════════════════════════════════════════

function getTecladoAdmin() {
    $teclado = [
        'keyboard' => [
            [
                ['text' => '📊 Estadísticas'],
                ['text' => '👥 Top Usuarios']
            ],
            [
                ['text' => '💸 Pagos Pendientes'],    // ← NUEVO
                ['text' => '✅ Aprobar Pagos']        // ← NUEVO
            ],
            [
                ['text' => '➕ Agregar Créditos'],
                ['text' => '🚫 Bloquear Usuario']
            ],
            [
                ['text' => '⭐ Hacer Premium'],
                ['text' => '📱 Gestionar Modelos']
            ],
            [
                ['text' => '📡 Stats API'],
                ['text' => '🔙 Volver al Menú']
            ]
        ],
        'resize_keyboard' => true,
        'one_time_keyboard' => false
    ];
    
    return json_encode($teclado);
}

// ═══════════════════════════════════════════════════════════════
// MODIFICACIÓN 4: REEMPLAZAR comandoStart (Línea ~720)
// ═══════════════════════════════════════════════════════════════

function comandoStart($chatId, $message, $db) {
    $telegramId = $message['from']['id'];
    $username = isset($message['from']['username']) ? $message['from']['username'] : '';
    $firstName = $message['from']['first_name'];
    $lastName = isset($message['from']['last_name']) ? $message['from']['last_name'] : '';
    
    $esNuevo = $db->registrarUsuario($telegramId, $username, $firstName, $lastName);
    
    $respuesta = "╔═══════════════════════════╗\n";
    $respuesta .= "║    🤖 BOT GENERADOR IMEI ║\n";
    $respuesta .= "╚═══════════════════════════╝\n\n";
    
    if ($esNuevo) {
        $respuesta .= "🎉 *¡Bienvenido {$firstName}!*\n\n";
        $respuesta .= "✨ Has recibido *" . CREDITOS_REGISTRO . " créditos* gratis\n";
        $respuesta .= "para empezar a usar el bot.\n\n";
    } else {
        $respuesta .= "👋 *¡Hola de nuevo {$firstName}!*\n\n";
    }
    
    $respuesta .= "━━━━━━━━━━━━━━━━━━━━━━━━\n";
    $respuesta .= "📱 *GENERADOR DE IMEI*\n";
    $respuesta .= "━━━━━━━━━━━━━━━━━━━━━━━━\n\n";
    
    $respuesta .= "🔹 Genera IMEIs válidos\n";
    $respuesta .= "🔹 Base de datos actualizada\n";
    $respuesta .= "🔹 Integración con IMEIDb\n";
    $respuesta .= "🔹 Sistema de créditos\n";
    $respuesta .= "🔹 Pagos automatizados 💳\n\n";
    
    $usuario = $db->getUsuario($telegramId);
    
    if ($usuario) {
        $respuesta .= "━━━━━━━━━━━━━━━━━━━━━━━━\n";
        $respuesta .= "💰 *TU CUENTA*\n";
        $respuesta .= "━━━━━━━━━━━━━━━━━━━━━━━━\n\n";
        
        if ($usuario['es_premium']) {
            $respuesta .= "⭐ *USUARIO PREMIUM*\n";
            $respuesta .= "✨ Generaciones ilimitadas\n";
        } else {
            $respuesta .= "💎 Créditos: *{$usuario['creditos']}*\n";
            $respuesta .= "📊 Generaciones: {$usuario['total_generaciones']}\n";
            
            if ($usuario['creditos'] < 5) {
                $respuesta .= "\n⚠️ *¡Créditos bajos!*\n";
                $respuesta .= "💰 Usa *Comprar Créditos* 👇\n";
            }
        }
    }
    
    $respuesta .= "\n━━━━━━━━━━━━━━━━━━━━━━━━\n";
    $respuesta .= "📲 Usa los botones 👇";
    
    $esAdmin = esAdmin($telegramId);
    enviarMensaje($chatId, $respuesta, 'Markdown', getTecladoPrincipal($esAdmin));
}

// ═══════════════════════════════════════════════════════════════
// MODIFICACIÓN 5: AGREGAR ESTAS FUNCIONES (Línea ~950, después de comandoAyuda)
// ═══════════════════════════════════════════════════════════════

// COPIAR TODO EL CONTENIDO DE: funciones_comandos_pago.php
// COPIAR TODO EL CONTENIDO DE: funciones_teclados_pago.php (los teclados adicionales)

// ═══════════════════════════════════════════════════════════════
// MODIFICACIÓN 6: MODIFICAR procesarActualizacion (Línea ~1568)
// ═══════════════════════════════════════════════════════════════

function procesarActualizacion($update, $db, $estados) {
    if (!isset($update['message'])) {
        return;
    }
    
    $message = $update['message'];
    $chatId = $message['chat']['id'];
    $telegramId = $message['from']['id'];
    $texto = isset($message['text']) ? trim($message['text']) : '';
    
    $usuario = $db->getUsuario($telegramId);
    $esAdminUser = esAdmin($telegramId);
    
    // ═══════════════════════════════════════════════════════════
    // INICIALIZAR SISTEMA DE PAGOS ← NUEVO
    // ═══════════════════════════════════════════════════════════
    $sistemaPagos = new SistemaPagos($db);
    
    // ═══════════════════════════════════════════════════════════
    // VERIFICAR SI ESTÁ ESPERANDO COMPROBANTE ← NUEVO
    // ═══════════════════════════════════════════════════════════
    if (isset($message['photo'])) {
        if (comandoRecibirComprobante($chatId, $telegramId, $message, $sistemaPagos, $estados, $db)) {
            return;
        }
    }
    
    // Comandos principales (EXISTENTES)
    if ($texto == '/start') {
        $estados->limpiarEstado($chatId);
        comandoStart($chatId, $message, $db);
    }
    elseif ($texto == '💳 Mis Créditos') {
        comandoMisCreditos($chatId, $telegramId, $db);
    }
    elseif ($texto == '📊 Mi Perfil') {
        comandoPerfil($chatId, $telegramId, $db);
    }
    elseif ($texto == '📜 Historial') {
        comandoHistorial($chatId, $telegramId, $db);
    }
    elseif ($texto == '❓ Ayuda') {
        comandoAyuda($chatId);
    }
    elseif (strpos($texto, '/info') === 0) {
        comandoInfo($chatId, $texto, $db);
    }
    elseif ($texto == '📱 Generar IMEI') {
        $estados->limpiarEstado($chatId);
        enviarMensaje($chatId, "Envía un TAC de 8 dígitos o IMEI de 15 dígitos.\n\nEjemplo: `35203310`\n\n💳 Costo: " . COSTO_GENERACION . " crédito");
    }
    
    // ═══════════════════════════════════════════════════════════
    // NUEVOS COMANDOS DE PAGOS ← AGREGAR ESTOS
    // ═══════════════════════════════════════════════════════════
    elseif ($texto == '💰 Comprar Créditos') {
        comandoComprarCreditosNuevo($chatId, $telegramId, $sistemaPagos);
    }
    elseif ($texto == '📋 Mis Órdenes') {
        comandoMisOrdenes($chatId, $telegramId, $sistemaPagos);
    }
    // Selección de paquetes
    elseif (strpos($texto, 'Básico') !== false) {
        comandoSeleccionarPaquete($chatId, $telegramId, 'basico', $sistemaPagos, $estados);
    }
    elseif (strpos($texto, 'Estándar') !== false) {
        comandoSeleccionarPaquete($chatId, $telegramId, 'estandar', $sistemaPagos, $estados);
    }
    elseif (strpos($texto, 'Premium') !== false && !strpos($texto, 'Hacer')) {
        comandoSeleccionarPaquete($chatId, $telegramId, 'premium', $sistemaPagos, $estados);
    }
    elseif (strpos($texto, 'VIP') !== false) {
        comandoSeleccionarPaquete($chatId, $telegramId, 'vip', $sistemaPagos, $estados);
    }
    // Métodos de pago
    elseif (strpos($texto, 'Pagar con Yape') !== false) {
        comandoProcesarMetodoPago($chatId, $telegramId, 'yape', $sistemaPagos, $estados);
    }
    elseif (strpos($texto, 'Pagar con Plin') !== false) {
        comandoProcesarMetodoPago($chatId, $telegramId, 'plin', $sistemaPagos, $estados);
    }
    elseif (strpos($texto, 'Transferencia Bancaria') !== false) {
        comandoProcesarMetodoPago($chatId, $telegramId, 'transferencia', $sistemaPagos, $estados);
    }
    elseif ($texto == '❌ Cancelar Compra' || $texto == '❌ Cancelar Orden') {
        $estados->limpiarEstado($chatId);
        enviarMensaje($chatId, "❌ Compra cancelada", 'Markdown', getTecladoPrincipal($esAdminUser));
    }
    
    // ═══════════════════════════════════════════════════════════
    // COMANDOS ADMIN - PAGOS ← AGREGAR ESTOS
    // ═══════════════════════════════════════════════════════════
    elseif ($texto == '👑 Panel Admin' && $esAdminUser) {
        enviarMensaje($chatId, "👑 *PANEL DE ADMINISTRACIÓN*\n\nSelecciona una opción:", 'Markdown', getTecladoAdmin());
    }
    elseif ($texto == '💸 Pagos Pendientes' && $esAdminUser) {
        comandoRevisarPagosPendientes($chatId, $sistemaPagos);
    }
    elseif ($texto == '✅ Aprobar Pagos' && $esAdminUser) {
        comandoRevisarPagosPendientes($chatId, $sistemaPagos);
    }
    elseif (strpos($texto, '/ver_orden') === 0 && $esAdminUser) {
        comandoVerOrden($chatId, $texto, $sistemaPagos);
    }
    elseif (strpos($texto, '/aprobar') === 0 && $esAdminUser) {
        comandoAprobarPagoAdmin($chatId, $texto, $telegramId, $sistemaPagos, $db);
    }
    elseif (strpos($texto, '/rechazar') === 0 && $esAdminUser) {
        comandoRechazarPagoAdmin($chatId, $texto, $sistemaPagos);
    }
    
    // ... resto de comandos existentes del admin ...
    
    elseif ($texto == '🔙 Volver al Menú' && $esAdminUser) {
        enviarMensaje($chatId, "Volviendo al menú principal...", 'Markdown', getTecladoPrincipal($esAdminUser));
    }
    elseif ($texto == '📊 Estadísticas' && $esAdminUser) {
        comandoEstadisticasAdmin($chatId, $db);
    }
    // ... resto del código existente ...
    
    elseif (!empty($texto) && $texto[0] != '/') {
        $procesadoComoModelo = procesarModelo($chatId, $texto, $estados, $db, $telegramId);
        
        if (!$procesadoComoModelo) {
            procesarTAC($chatId, $texto, $telegramId, $db, $estados);
        }
    }
}

// ═══════════════════════════════════════════════════════════════
// MODIFICACIÓN 7: AGREGAR AL FINAL (Antes de modoWebhook)
// ═══════════════════════════════════════════════════════════════

function comandoAprobarPagoAdmin($chatId, $texto, $adminId, $sistemaPagos, $db) {
    $partes = explode(' ', $texto);
    
    if (count($partes) < 2) {
        enviarMensaje($chatId, "❌ Uso: `/aprobar [ORDEN_ID]`");
        return;
    }
    
    $ordenId = intval($partes[1]);
    $orden = $sistemaPagos->obtenerOrden($ordenId);
    
    if (!$orden) {
        enviarMensaje($chatId, "❌ Orden no encontrada");
        return;
    }
    
    if ($orden['estado'] == 'aprobada') {
        enviarMensaje($chatId, "⚠️ Esta orden ya fue aprobada anteriormente");
        return;
    }
    
    if ($sistemaPagos->aprobarOrden($ordenId, $adminId)) {
        $respuesta = "✅ *ORDEN APROBADA*\n\n";
        $respuesta .= "🆔 Orden #{$ordenId}\n";
        $respuesta .= "💎 Créditos: {$orden['creditos']}\n";
        $respuesta .= "👤 Usuario: `{$orden['telegram_id']}`\n\n";
        $respuesta .= "Los créditos han sido acreditados automáticamente.";
        
        enviarMensaje($chatId, $respuesta);
        
        // Notificar al usuario
        $mensajeUsuario = "🎉 *¡PAGO APROBADO!*\n\n";
        $mensajeUsuario .= "✅ Tu pago ha sido verificado\n";
        $mensajeUsuario .= "💎 Se han agregado *{$orden['creditos']} créditos*\n";
        $mensajeUsuario .= "a tu cuenta.\n\n";
        $mensajeUsuario .= "━━━━━━━━━━━━━━━━━━━━━━━━\n\n";
        $mensajeUsuario .= "🔖 Orden: `{$orden['codigo_orden']}`\n";
        $mensajeUsuario .= "💰 Monto: {$orden['moneda']} {$orden['monto']}\n\n";
        $mensajeUsuario .= "¡Gracias por tu compra! 🙏\n";
        $mensajeUsuario .= "Ya puedes usar tus créditos.";
        
        enviarMensaje($orden['telegram_id'], $mensajeUsuario);
    } else {
        enviarMensaje($chatId, "❌ Error al aprobar la orden");
    }
}

function comandoRechazarPagoAdmin($chatId, $texto, $sistemaPagos) {
    $partes = explode(' ', $texto, 3);
    
    if (count($partes) < 2) {
        enviarMensaje($chatId, "❌ Uso: `/rechazar [ORDEN_ID] [motivo]`");
        return;
    }
    
    $ordenId = intval($partes[1]);
    $motivo = isset($partes[2]) ? $partes[2] : 'No especificado';
    
    $orden = $sistemaPagos->obtenerOrden($ordenId);
    
    if (!$orden) {
        enviarMensaje($chatId, "❌ Orden no encontrada");
        return;
    }
    
    if ($sistemaPagos->rechazarOrden($ordenId, $motivo)) {
        $respuesta = "❌ *ORDEN RECHAZADA*\n\n";
        $respuesta .= "🆔 Orden #{$ordenId}\n";
        $respuesta .= "📝 Motivo: {$motivo}";
        
        enviarMensaje($chatId, $respuesta);
        
        // Notificar al usuario
        $mensajeUsuario = "❌ *PAGO RECHAZADO*\n\n";
        $mensajeUsuario .= "Tu pago no pudo ser verificado.\n\n";
        $mensajeUsuario .= "🔖 Orden: `{$orden['codigo_orden']}`\n";
        $mensajeUsuario .= "📝 Motivo: {$motivo}\n\n";
        $mensajeUsuario .= "━━━━━━━━━━━━━━━━━━━━━━━━\n\n";
        $mensajeUsuario .= "Si crees que es un error, contacta\n";
        $mensajeUsuario .= "con soporte: @CHAMOGSM";
        
        enviarMensaje($orden['telegram_id'], $mensajeUsuario);
    } else {
        enviarMensaje($chatId, "❌ Error al rechazar la orden");
    }
}

?>
